class InboxDrop < BaseDrop
end
