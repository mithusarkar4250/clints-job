<template>
  <div class="search">
    <i class="icon ion-ios-search-strong" />
    <input class="input" type="email" :placeholder="$t('CHAT_LIST.SEARCH.INPUT')">
  </div>
</template>
<script>
export default {

};
</script>
