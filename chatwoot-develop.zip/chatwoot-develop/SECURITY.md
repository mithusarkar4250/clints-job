# Security Policy

## Reporting a Vulnerability

We use [huntr.dev](https://huntr.dev/) for security issues that affect our project. If you believe you have found a vulnerability, please disclose it via this [form](https://huntr.dev/bounties/disclose). 
This will enable us to review the vulnerability, fix it promptly, and reward you for your efforts.

If you have any questions about the process, feel free to reach out to hello@chatwoot.com.
